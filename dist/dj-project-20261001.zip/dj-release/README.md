# AI DJ 项目完整包 (2026-10-01)

The Weeknd lofi 全辑 Agent DJ 混音系统: 曲目分析 → 编排决策 → 技巧渲染 → 线上播放页。

## 快速导览
- `dj-project/README.md` — 项目结构与版本谱系
- `dj-project/lofi-engine/` — v1-v4 四版编排引擎(含时间轴 JSON)
- `dj-project/miaomi-dj/source/` — 核心 DJ Agent 33 模块(Mixxx 集成)
- `dj-project/auret-legacy/` — 第一代渲染脚本与页面
- `dj-project/qa-scripts/` — Playwright 线上验证脚本
- `sleep-dj.html` — 双 tab 播放页(NIGHT SHIFT 53:50 / FLIGHT 89:15)线上版源码
- `architecture/ai-dj-gpt-reference.html` — Archify 交互架构图
- `DEPLOY.md` / `PIPELINE.md` — 部署与流水线文档

## 四版串烧
v1 55min 能量缓降 · v2 54min Agent 技巧决策 · v3 15min 精华 · v4 89min 长途飞行三幕

音频与源曲不入包(版权)。
